## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
if (!require(SchistoTransmissionModel)) { install.packages("SchistoTransmissionModel", dependencies = TRUE)
}

## -----------------------------------------------------------------------------
# Define model parameters (names must be spelt exactly but order doesn't matter)
theta <- c(    
  R0                  = 2.5,
  R0_weight           = 0.4,
  NhNs                = 0.3,
  kW                  = 0.4,
  decay_immunity      = 6,
  protection_immunity = 0.5,
  epg_constant        = 5.81,
  ige_constant        = 0.5 
)

## -----------------------------------------------------------------------------
# Define treatment parameters (names must be spelt exactly but order doesn't matter)
tx_pars <- c(
  input_tx_times = 0,
  toggle_tx      = 1,
  start_tx       = 20,
  n_tx           = 3,
  freq_tx        = 1,
  sac_coverage   = 0.75,
  efficacy       = 0.95,
  min_tx_age     = 5,
  max_tx_age     = 30,
  cov_weight     = 0.8
)

## -----------------------------------------------------------------------------
runtime <- 30     #30 years
stepsize <- 1/12  #1 month

## -----------------------------------------------------------------------------
sim <- RunTransmissionModel(
  theta    = theta,
  tx_pars  = tx_pars, 
  runtime  = runtime, 
  stepsize = stepsize, 
  user_tx_times   = NA, 
  user_cov_weight = NA, 
  time_extract_states = NA
)

## ----fig.show='hold'----------------------------------------------------------
plot_time_output <- function(sim){
  plot(sim$time, sim$worm_burden, 'l', xlab = "Time (years)", ylab = "Mean worm burden")
  plot(sim$time, sim$epg, 'l', xlab = "Time (years)", ylab = "Mean epg")
}
plot_time_output(sim)

## ----fig.show='hold'----------------------------------------------------------
# Specify time index to extract model output
time_index <- which(sim$time == tx_pars["start_tx"])

# Define a function to plot worm burdens & epgs at particular time index
plot_age_output <- function(sim, time_index) {
  
  # Plot worm burdens
  plot(sim$age, sim$worm_burden_age_female[time_index,], 'l', xlab = "Age (years)", ylab = "Worm burden")
  lines(sim$age, sim$worm_burden_age_male[time_index,], lty=2, col="red")
  
  # Plot epgs
  plot(sim$age, sim$epg_age_female[time_index,], 'l', xlab = "Age (years)", ylab = "epg")
  lines(sim$age, sim$epg_age_male[time_index,], lty=2, col="red")
  
}

# Call function to make plots
plot_age_output(sim, time_index)

## -----------------------------------------------------------------------------
# set toggle to 1 so model uses 'user_tx_times' and `user_cov_weight`, not MDA times and coverage weights informed by 'tx_pars' parameters
tx_pars["input_tx_times"] <- 1

# then specify some example treatment times
user_tx_times <- c(tx_pars["start_tx"], tx_pars["start_tx"]+5, tx_pars["start_tx"]+7)

# and associated coverage weights
user_cov_weight <- c(0.5, 1, 0.2)

## -----------------------------------------------------------------------------
user_t_extract_states <- tx_pars["start_tx"] + 3  #3 years after first treatment

## -----------------------------------------------------------------------------
sim <- RunTransmissionModel(
  theta    = theta,
  tx_pars  = tx_pars, 
  runtime  = runtime, 
  stepsize = stepsize, 
  user_tx_times   = user_tx_times, 
  user_cov_weight = user_cov_weight, 
  time_extract_states = user_t_extract_states
)

## -----------------------------------------------------------------------------
plot_time_output(sim)

## -----------------------------------------------------------------------------
## Uncomment to run
# head(sim$male_states_out)
# head(sim$female_states_out)

